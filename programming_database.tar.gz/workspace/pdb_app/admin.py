from django.contrib import admin
from pdb_app.models import Item, Category

admin.site.register(Item)
admin.site.register(Category)
