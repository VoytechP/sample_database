from django.apps import AppConfig


class PdbAppConfig(AppConfig):
    name = 'pdb_app'
